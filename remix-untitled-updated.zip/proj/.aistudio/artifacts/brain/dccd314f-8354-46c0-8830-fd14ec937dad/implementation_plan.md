# 180-Second State-Based Stability Lock for AI Reports

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were confirmed during the interactive interview:
> - **Scope**: The 180-second stability lock applies across **all AI report components** (`DirectChartAnalysisModal`, `ComprehensiveStockReportModal`, `TechnicalAdvisorModal`, `DailyAnalysisReportModal`, and Egypt Gold report).
> - **Timer Expiration**: After 180 seconds elapse, the lock automatically releases and **background periodic auto-refreshes resume**.
> - **Visual Feedback**: The remaining lock duration is displayed via an interactive **progress bar with countdown timer** and an **instant manual refresh button** to immediately bypass the lock when needed.

---

## 1. Overview & Core Concept

When users request an AI analysis (such as the Direct TradingView Chart AI analysis, 360 Stock report, or Technical Advisor Council), background price updates or ticker polling can trigger component re-evaluations, causing the report to flicker, disappear, or re-run loading spinners unexpectedly.

This feature implements a centralized, state-based lock hook (`useReportLock`) that:
1. Records a `lockedUntilTimestamp` when an analysis report is requested or opened.
2. Freezes background auto-refresh triggers for that specific component for **180 seconds** (3 minutes).
3. Renders a smooth visual progress bar showing the remaining lock time (`2:59` down to `0:00`).
4. Provides an instant "تحديث فوري 🔄" button that bypasses the lock and restarts the 180s cycle with fresh data.
5. Automatically resumes regular background auto-refreshing once the 180 seconds expire.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Requesting an Analysis**: The user clicks on any stock analysis (e.g. "تحليل مباشر بالذكاء الاصطناعي" or "تقرير 360° شامل").
2. **Lock Activation**: The analysis loads, and the report header immediately displays the stability lock badge:
   - A lock icon with `"تقرير مثبت ومستقر 🛡️"`
   - A countdown timer (e.g. `02:48`) and a dynamic horizontal progress bar showing the 180-second window.
3. **During the 180s Window**: Background market ticks and timer intervals in the background will NOT re-trigger Gemini API calls or reset the scroll/state of the modal.
4. **Manual Override**: The user can click `"تحديث فوري 🔄"` at any time to bypass the remaining lock duration, fetch fresh quotes, and reset the 180s timer.
5. **Expiration & Resume**: When the progress bar reaches 100% (after 180 seconds), the lock indicator smoothly transitions to `"التحديث التلقائي نشط"`, allowing standard background refresh cycles to resume.

### Visual Styling & Theme
- **Color Tokens**:
  - Lock Active: Subdued Cyan/Emerald surface (`bg-cyan-950/40 border-cyan-500/30 text-cyan-200`)
  - Progress Bar: Animated fill (`bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-1000 ease-linear`)
  - Manual Refresh Button: Interactive button with hover brightness (`bg-cyan-600 hover:bg-cyan-500 text-white`)
- **Typography**: Strict tabular numerals (`font-mono tabular-nums`) for the countdown timer to prevent layout jitter.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Centralized Reusable Hook (`useReportLock`) vs Component-Specific State**
  - *Chosen Approach*: Create a centralized hook `src/hooks/useReportLock.ts` storing lock state in memory with optional session persistence keyed by component and symbol (e.g., `direct_ai_TMGH`, `comprehensive_SWDY`).
  - *Why*: Eliminates code duplication across all 5 report modals, ensures consistent 180-second timing, and guarantees that closing and reopening a modal within the 180s window keeps the existing cached analysis without unnecessary duplicate LLM API calls.
  - *Alternatives Considered*: Storing timestamps in `App.tsx` props would cause prop drilling; storing purely in local component state would lose the lock if a modal is briefly toggled.

- **Decision 2: Automatic Resume After 180 Seconds**
  - *Chosen Approach*: When `Date.now() >= lockedUntilTimestamp`, `isLocked` evaluates to `false`, allowing the next scheduled background refresh tick to update the data cleanly.
  - *Why*: Directly fulfills the user's selected preference to resume auto-refresh automatically while preventing premature re-runs during active reading.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                          EGX Radar Application                         │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│   ┌─────────────────────────┐          ┌───────────────────────────┐   │
│   │ App.tsx Market Poller   │          │ User Trigger (Analysis)   │   │
│   │ (30s / 60s live ticks)  │          │ (Click stock / modal)     │   │
│   └────────────┬────────────┘          └─────────────┬─────────────┘   │
│                │                                     │                 │
│                ▼                                     ▼                 │
│   ┌────────────────────────────────────────────────────────────┐       │
│   │                 useReportLock(reportKey, 180)              │       │
│   │  • lockedUntilTimestamp: number                            │       │
│   │  • isLocked: boolean (now < lockedUntilTimestamp)          │       │
│   │  • secondsRemaining: number (180 -> 0)                     │       │
│   │  • progressPct: number (0% -> 100%)                        │       │
│   │  • triggerManualRefresh(): bypass & reset 180s timer       │       │
│   └────────────┬─────────────────────────────────────┬─────────┘       │
│                │ If isLocked == true                 │ Fresh call or   │
│                │ (Suppress auto-fetch)               │ Manual Refresh  │
│                ▼                                     ▼                 │
│   ┌─────────────────────────┐          ┌───────────────────────────┐   │
│   │ Keep Stable Analysis    │          │ Execute Fresh AI API Call │   │
│   │ (Zero Spinner / Reload) │          │ (/api/gemini/* or council)│   │
│   └─────────────────────────┘          └───────────────────────────┘   │
│                                                                        │
│   Components Connected:                                                │
│   ├─ DirectChartAnalysisModal.tsx (TradingView Chart AI)               │
│   ├─ ComprehensiveStockReportModal.tsx (360° Stock Technical Report)   │
│   ├─ TechnicalAdvisorModal.tsx (3-Model AI Council)                    │
│   ├─ DailyAnalysisReportModal.tsx (Daily Market Brief)                 │
│   └─ EgyptGoldTickerBar.tsx (Live Gold & Saghah Benchmark)             │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Key Modules & Files to Create/Update

1. **`src/hooks/useReportLock.ts`** (New File):
   - Hook managing `isLocked`, `remainingSeconds`, `progressPct`, and `forceRefresh()`.
   - Global in-memory timestamp dictionary `reportLockRegistry` keyed by `${componentId}_${symbol || 'global'}` so locks survive modal close/reopen within the 180s window.
   - 1-second interval effect that smoothly decrements remaining seconds and updates the visual progress percentage.

2. **`src/components/ReportStabilityLockBar.tsx`** (New File):
   - Reusable UI component rendering the progress bar, lock shield icon, countdown timer, and `"تحديث فوري 🔄"` button.
   - Built with high-contrast accessibility and dark palette styling.

3. **`src/components/DirectChartAnalysisModal.tsx`** (Update):
   - Integrate `useReportLock('direct_chart', stock.symbol, 180)`.
   - Suppress effect re-runs when `isLocked` is true unless triggered by `forceRefresh`.
   - Mount `ReportStabilityLockBar` in the modal header.

4. **`src/components/ComprehensiveStockReportModal.tsx`** (Update):
   - Integrate `useReportLock('comprehensive_360', stock.symbol, 180)`.
   - Mount `ReportStabilityLockBar` beside the price verification badge.

5. **`src/components/TechnicalAdvisorModal.tsx`** (Update):
   - Integrate `useReportLock('advisor_council', currentStock.symbol, 180)`.
   - Protect the AI Council verdict from micro-tick resets.

6. **`src/components/DailyAnalysisReportModal.tsx` & `src/components/DailyAnalysisReportTab.tsx`** (Update):
   - Integrate 180s stability lock for the automated daily analysis brief.

7. **Verification**:
   - Run `npm run lint` (`tsc --noEmit`) and verify that all report locks cleanly maintain analysis stability for 180s without accidental resets or dead clicks.
